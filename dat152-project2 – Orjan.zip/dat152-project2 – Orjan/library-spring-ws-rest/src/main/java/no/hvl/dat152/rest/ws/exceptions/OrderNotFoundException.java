/**
 * 
 */
package no.hvl.dat152.rest.ws.exceptions;

/**
 * 
 */
public class OrderNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public OrderNotFoundException(String customMessage) {
		super(customMessage);
	}
	
}
