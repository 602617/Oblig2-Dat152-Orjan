/**
 * 
 */
package no.hvl.dat152.rest.ws.exceptions;

/**
 * 
 */
public class UpdateBookFailedException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public UpdateBookFailedException(String customMessage) {
		super(customMessage);
	}
	
}
